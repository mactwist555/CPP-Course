#include <iostream>
using namespace std;

/*
In this program, 1, 2, and 3 are valid choices.
Everything else is invalid.

If the user enters
an invalid answer, the program should write
"Invalid, try again:", and continue looping until
the user finally enters something valid.

The program should not continue until a valid number
is entered.
*/

int GetChoice( int min, int max )
{
    int c;
    cin >> c;
    while ( c < min && c > max )
    {
        cout << "Invalid, try again:" << endl;
        cin >> c;
    }
    return c;
}

int main()
{
    cout << "Enter a number between 1 and 3: ";

    int choice = GetChoice( 1, 3 );

    cout << "You chose " << choice << endl;

    return 0;
}
