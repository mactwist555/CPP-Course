#include <iostream>
using namespace std;

/*
This program should only display "Twenty One"
when it is run.
*/

int main()
{
    int age = 21;

    if ( age = 21 )
    {
        cout << "Twenty One";
    }

    if ( age = 22 )
    {
        cout << "Twenty Two";
    }

    return 0;
}
